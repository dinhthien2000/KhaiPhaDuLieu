Hướng dẫn : 
Ngôn ngữ : python
Công cụ : https://www.kaggle.com/